# FLOXYBLINGS MAGAZINE — CMS deployment guide

## Please read this before deploying
This bundle includes your existing static website, a Cloudflare Pages Functions API, a D1 schema, a phone-friendly admin interface, and public-page rendering for published managed content. It is designed to avoid R2 by storing small media files in D1.

**Important limitations:**
- The Cloudflare dashboard's static drag-and-drop upload does not deploy Pages Functions. A ZIP upload alone will not activate the API or admin CMS. Deploy using a Git-connected Pages project or Wrangler. This package is source code, not a one-click activation ZIP.
- The no-R2 upload route is limited to approximately 450 KB per image/MP4 file and consumes your D1 storage/queries. It is not suitable for large videos. For larger videos, host them on a free video platform and paste the URL in the dashboard.
- Free plans have quotas and can change. This bundle does not promise unlimited storage or that all services will remain free forever.
- The existing public site remains static; published products/articles/pages are added in a “Latest products, stories & updates” section. This does not rewrite the existing hard-coded sections or navigation automatically.

## Required Cloudflare setup
1. Sign in at https://dash.cloudflare.com and open Workers & Pages.
2. Open your existing `fbmagzn` Pages project (or create a separate test project first to protect the live site).
3. In D1 SQL Database, create `floxyblings-content` if it does not already exist.
4. Open that database's Console and execute the entire contents of `schema.sql` once.
5. In the Pages project, open Settings → Bindings and add a D1 database binding:
   - Variable name: `DB`
   - Database: `floxyblings-content`
   Save the binding and redeploy.
6. In Pages project Settings → Variables and Secrets, add a secret:
   - Name: `ADMIN_SETUP_KEY`
   - Value: create a long, random, private string (at least 32 characters). Keep it private; do not put it in HTML or share it.
7. Deploy the package using a supported method below. Add the binding/secret to the production environment and preview environment only if you need previews.

## Deployment methods
### Method A — Git integration (recommended for ongoing updates)
Cloudflare Pages Settings → Builds & deployments → Connect to Git. Connect a repository containing the **extracted contents** of this ZIP (the HTML files, `functions/`, `admin/`, `schema.sql`, and other files at repository root). Set build command to blank/no command and output directory to `.` if the setup screen permits it. Pages Functions must be included in the repository at `/functions`.

### Method B — Wrangler
A compatible computer or command-line environment is required. Install Wrangler, set the real D1 database ID in `wrangler.toml`, then deploy the Pages project with Wrangler. The dashboard ZIP drag-and-drop method is not a replacement for this.

## First administrator setup
After the code is deployed and the D1 binding/schema and `ADMIN_SETUP_KEY` are configured, open:
`https://YOUR-PAGES-DOMAIN/admin/`
Enter the exact `ADMIN_SETUP_KEY`, your email address, and a strong password (12+ characters) to create the first administrator. The setup endpoint permanently closes after the first administrator is created. Then sign in normally.

## Test checklist
- Open `/api/health` and confirm it returns `"ok":true`.
- Open `/api/auth/me` and confirm it returns JSON.
- Open `/admin/` and create the first administrator.
- Add a draft product, then publish it; open the public site and look for the managed-content section.
- Upload a small image under 450 KB; verify it appears in Media library.
- Do not delete or replace the existing production deployment until a test deployment passes.

## Troubleshooting
- 404 at `/api/health`: Pages Functions have not been deployed, or the package was uploaded only as static assets.
- “Database binding DB is missing”: add the D1 binding with exact name `DB` and redeploy.
- “ADMIN_SETUP_KEY secret is not configured”: add that secret in Pages settings and redeploy.
- SQL/schema errors: run `schema.sql` in the D1 Console, then retry.
- Upload rejected: file exceeds the small-file limit or is not JPG/PNG/WEBP/GIF/MP4. Compress it or use an external video URL.

## Security
Never publish your setup key or admin password. Keep the original ZIP as a backup. Do not expose a setup key in screenshots. Use HTTPS and a unique password. The setup flow is intended for first-time initialization; create the first admin only after deployment is private/ready.
