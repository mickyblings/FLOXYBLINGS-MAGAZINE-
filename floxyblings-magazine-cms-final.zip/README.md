# FLOXYBLINGS MAGAZINE
Original multi-page commercial website plus a Cloudflare Pages Functions-based CMS starter.

See `DEPLOY-READ-ME-FIRST.md` before deploying. CMS endpoints require Pages Functions, a D1 database binding named `DB`, the SQL in `schema.sql`, and a secret named `ADMIN_SETUP_KEY`. Dashboard URL after deployment: `/admin/`.

The admin supports CRUD for products, articles, custom pages, links, and media records. Published managed content is appended to public pages. Direct file storage without R2 is limited to approximately 450 KB per image or MP4 and should be treated as a small-file option, not unlimited media hosting.
