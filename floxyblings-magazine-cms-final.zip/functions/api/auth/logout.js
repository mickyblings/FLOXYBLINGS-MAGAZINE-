import {json,cookie,sha256,cookieHeader} from '../_utils.js';
export async function onRequestPost({request,env}){const t=cookie(request,'fbmgzn_session');if(t&&env.DB)await env.DB.prepare('DELETE FROM sessions WHERE token_hash=?').bind(await sha256(t)).run();return json({ok:true},200,{'set-cookie':cookieHeader('',0)});}
