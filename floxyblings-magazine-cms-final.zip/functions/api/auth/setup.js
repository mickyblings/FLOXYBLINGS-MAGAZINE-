import {json,bodyJSON,sha256,cookieHeader,validEmail} from '../_utils.js';
export async function onRequestPost({request,env}){
 if(!env.DB)return json({error:'Database binding DB is missing.'},503);
 const setupKey=env.ADMIN_SETUP_KEY;if(!setupKey)return json({error:'ADMIN_SETUP_KEY secret is not configured. Add it in Cloudflare Pages Settings > Variables and Secrets.'},503);
 const data=await bodyJSON(request);if(!data||data.setupKey!==setupKey)return json({error:'Setup key is incorrect.'},403);
 if(!validEmail(data.email)||typeof data.password!=='string'||data.password.length<12)return json({error:'Enter a valid email and a password of at least 12 characters.'},400);
 const count=await env.DB.prepare('SELECT COUNT(*) AS n FROM admins').first();if(count?.n>0)return json({error:'An administrator already exists. Use the login form.'},409);
 const salt=crypto.randomUUID()+crypto.randomUUID();const passwordHash=await sha256(salt+':'+data.password);
 try{const r=await env.DB.prepare('INSERT INTO admins(email,password_hash) VALUES(?,?)').bind(data.email.toLowerCase(),salt+':'+passwordHash).run();const token=crypto.randomUUID()+crypto.randomUUID();const tokenHash=await sha256(token);const expiry=Math.floor(Date.now()/1000)+86400*7;await env.DB.prepare('INSERT INTO sessions(token_hash,admin_id,expires_at) VALUES(?,?,?)').bind(tokenHash,r.meta.last_row_id,expiry).run();return json({ok:true,email:data.email.toLowerCase()},200,{'set-cookie':cookieHeader(token,86400*7)});}catch(e){return json({error:'Could not create administrator. Check that schema.sql was imported and retry.'},500)}
}
