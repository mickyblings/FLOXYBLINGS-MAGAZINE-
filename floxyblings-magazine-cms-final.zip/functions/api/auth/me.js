import {json,currentAdmin} from '../_utils.js';
export async function onRequestGet({request,env}){if(!env.DB)return json({error:'Database binding DB is missing.'},503);const count=await env.DB.prepare('SELECT COUNT(*) AS n FROM admins').first();const admin=await currentAdmin(request,env);return json({setupRequired:!(count?.n>0),authenticated:!!admin,email:admin?.email||null});}
