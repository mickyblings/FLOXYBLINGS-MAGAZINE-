const enc = new TextEncoder();
export const json = (data, status=200, headers={}) => new Response(JSON.stringify(data), {status, headers:{'content-type':'application/json; charset=utf-8','cache-control':'no-store',...headers}});
export async function bodyJSON(request){ try{return await request.json()}catch{return null} }
export async function sha256(s){const b=await crypto.subtle.digest('SHA-256',enc.encode(s));return [...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,'0')).join('')}
export function cookie(request,name){const raw=request.headers.get('Cookie')||'';for(const p of raw.split(';')){const i=p.trim().indexOf('=');if(i>0&&p.trim().slice(0,i)===name)return decodeURIComponent(p.trim().slice(i+1))}return ''}
export function cookieHeader(value,maxAge){return `fbmgzn_session=${encodeURIComponent(value)}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=${maxAge}`}
export async function currentAdmin(request,env){const token=cookie(request,'fbmgzn_session');if(!token)return null;const hash=await sha256(token);return await env.DB.prepare('SELECT admins.id, admins.email FROM sessions JOIN admins ON admins.id=sessions.admin_id WHERE sessions.token_hash=? AND sessions.expires_at>?').bind(hash,Math.floor(Date.now()/1000)).first()}
export function slugify(s){return String(s||'item').normalize('NFKD').toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'').slice(0,80)||'item'}
export function validEmail(s){return typeof s==='string'&&s.length<=254&&/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s)}
