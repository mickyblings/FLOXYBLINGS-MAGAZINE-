import {json} from './_utils.js';
export async function onRequestGet({env}){try{const r=await env.DB.prepare('SELECT 1 AS ok').first();return json({ok:r?.ok===1,database:'connected',app:'FLOXYBLINGS MAGAZINE CMS'});}catch(e){return json({ok:false,error:'Database binding/schema not ready'},503)}}
