
document.addEventListener('DOMContentLoaded', function(){
  const toggle = document.querySelector('.menu-toggle');
  const nav = document.querySelector('.nav');
  if(toggle && nav){
    toggle.addEventListener('click', function(){
      const open = nav.classList.toggle('open');
      toggle.setAttribute('aria-expanded', String(open));
      toggle.textContent = open ? '✕' : '☰';
    });
    nav.querySelectorAll('a').forEach(a => a.addEventListener('click', () => {
      nav.classList.remove('open'); toggle.setAttribute('aria-expanded','false'); toggle.textContent='☰';
    }));
  }
  document.querySelectorAll('[data-year]').forEach(el => el.textContent = new Date().getFullYear());
  const form = document.getElementById('enquiry-form');
  if(form){
    form.addEventListener('submit', function(e){
      e.preventDefault();
      const name = document.getElementById('name').value.trim();
      const contact = document.getElementById('contact').value.trim();
      const topic = document.getElementById('topic').value;
      const message = document.getElementById('message').value.trim();
      if(!name || !topic || !message){ document.getElementById('form-status').textContent='Please complete your name, enquiry topic and message.'; return; }
      const text = `Hello FLOXYBLINGS MAGAZINE, my name is ${name}. Enquiry: ${topic}. Contact: ${contact || 'Not provided'}. Details: ${message}`;
      window.open('https://wa.me/2290164371094?text=' + encodeURIComponent(text), '_blank', 'noopener');
      document.getElementById('form-status').textContent='WhatsApp should open with your message ready to send. Please review it before sending.';
    });
  }
});
